import { Component } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

declare var Stimulsoft: any;

@Component({
	selector: 'app-root',
	template: `<div>
					<h2>Stimulsoft Reports.JS - Aula10Json_Thiago.mrt - Viewer</h2>
					<div id="viewerContent"></div>
				</div>`,
	encapsulation: ViewEncapsulation.None
})

export class AppComponent {
	options: any = new Stimulsoft.Viewer.StiViewerOptions();
	viewer: any = new Stimulsoft.Viewer.StiViewer(this.options, 'StiViewer', false);

	ngOnInit() {
		var report = Stimulsoft.Report.StiReport.createNewReport();
		report.loadFile("reports/Aula10Json_Thiago.mrt");

		this.viewer.report = report;
		this.viewer.renderHtml("viewerContent");
	}

	constructor(private http: HttpClientModule) {

	}
}